# config.py

database = {
    'user': 'root',
    'password': '',
    'database': 'bbt'
}

secret_key = '123456'

